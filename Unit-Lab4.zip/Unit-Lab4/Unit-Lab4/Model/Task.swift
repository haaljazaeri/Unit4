import Foundation
import CoreLocation
import UIKit


class Task {
    
    var title: String!
    var description: String?
    var image: UIImage?
    var location: CLLocation?
    
    init(title: String!, description: String?, image: UIImage?, location: CLLocation? = nil) {
        self.title = title
        self.description = description
        self.image = image
    }
    
    var isCompleted: Bool {
        if let _ = image {
            return true
        }
        return false
    }
}
