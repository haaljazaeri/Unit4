
import UIKit

protocol AddNewViewControllerDelegate {
    func addTask(task: Task)
}

class AddNewViewController: UIViewController {

    @IBOutlet weak var descFld: UITextField!
    @IBOutlet weak var titleFld: UITextField!
    
    var delegate: AddNewViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction func doneActionButton(_ sender: Any) {
        var task = Task(title: titleFld.text, description: descFld.text, image: nil)
        delegate?.addTask(task: task)
        self.dismiss(animated: true)
    }
}
