import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var listTableView: UITableView!
    
    var tasks: [Task] = [] {
        didSet {
            listTableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        listTableView.register(ListTableViewCell.self)
    }
    
    @IBAction func addTaskAction(_ sender: Any) {
        if let addVC = storyboard?.instantiateViewController(withIdentifier: "AddNewViewController") as? AddNewViewController {
            addVC.delegate = self
            self.present(addVC, animated: true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        listTableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let taskCell = listTableView.dequeueReusableCell(withIdentifier: ListTableViewCell.identifier, for: indexPath) as? ListTableViewCell {
            taskCell.task = tasks[indexPath.row]
            if let _ = tasks[indexPath.row].image {
                taskCell.accessoryType = .checkmark
            } else {
                taskCell.accessoryType = .none
            }
            return taskCell
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let detailVC = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController {
            detailVC.task = tasks[indexPath.row]
            self.navigationController?.pushViewController(detailVC, animated: true)
        }
    }
}

extension ViewController: AddNewViewControllerDelegate {
    
    func addTask(task: Task) {
        tasks.append(task)
    }
}

