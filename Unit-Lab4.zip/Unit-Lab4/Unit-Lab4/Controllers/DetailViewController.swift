import UIKit
import MapKit
import PhotosUI

class DetailViewController: UIViewController {
    
    var task: Task?
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var addButon: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        mapView.delegate = self
        if let task = task, let _ = task.image {
            addButon.isHidden = true
            mapView.isHidden = false
        } else {
            addButon.isHidden = false
            mapView.isHidden = true
        }
        
        titleLbl.text = task?.title
        descLbl.text = task?.description
    }
    
    @IBAction func addAction(_ sender: Any) {
        if PHPhotoLibrary.authorizationStatus(for: .readWrite) != .authorized {
            // Request photo library access
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] status in
                switch status {
                case .authorized:
                    DispatchQueue.main.async {
                        self?.presentImagePicker() }
                default:
                    print()
                    //                    DispatchQueue.main.async {
                    //                        // Helper method to show settings alert
                    //                        self?.presentGoToSettingsAlert() }
                }
            }
        } else {
            presentImagePicker()
        }
    }
    
    
    func  presentImagePicker()  {
        var config = PHPickerConfiguration(photoLibrary: PHPhotoLibrary.shared())
        // Set the filter to only show images as options (i.e. no videos, etc.).
        config.filter = .images
        // Request the original file format. Fastest method as it avoids transcoding.
        config.preferredAssetRepresentationMode = .current // Only allow 1 image to be selected at a time.
        config.selectionLimit = 1
        // Instantiate a picker, passing in the configuration.
        let picker = PHPickerViewController(configuration: config)
        // Set the picker delegate so we can receive whatever image the user picks.
        picker.delegate = self
        // Present the picker.
        present(picker, animated: true)
    }
    
}

extension DetailViewController: PHPickerViewControllerDelegate {
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        
        picker.dismiss(animated: true)
        let result = results.first
        // Get image location
        // PHAsset contains metadata about an image or video (ex. location, size, etc.)
        guard let assetId = result?.assetIdentifier,
              let location = PHAsset.fetchAssets(withLocalIdentifiers: [assetId], options: nil).firstObject else {return}
        
        if let _ = location.location {
            self.mapView.isHidden = false
            self.addButon.isHidden = true
            print(" Image location coordinate: \(location.location?.coordinate)")
        }
        
        guard let provider = result?.itemProvider, provider.canLoadObject(ofClass: UIImage.self) else {return}
        provider.loadObject(ofClass: UIImage.self) { [weak self] object, error in
            // Handle any errors
            if let error = error {
                DispatchQueue.main.async { [weak self] in
                }
            }
            // Make sure we can cast the returned object to a UIImage
            guard let image = object as? UIImage else { return }
            print(" We have an image!")
            DispatchQueue.main.async { [weak self] in
                // Set the picked image and location on the task
                self?.task?.image = image
                self?.task?.location = location.location
                
                // Update the UI since we've updated the task
                //                self?.updateUI()
                // Update the map view since we now have an image an location
                self?.updateMapView()
            }
        }
    }
    
    private func updateMapView() {
        guard let imageLocation = task!.location else { return }
        let coordinate = imageLocation.coordinate
        // Set the map view's region based on the coordinate of the image.
        let region = MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta:20, longitudeDelta: 20))
        mapView.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        mapView.addAnnotation(annotation)
    }
}

extension DetailViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "custom")
        
        if annotationView == nil {
            //Create View
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "custom")
        } else {
            
            let pinImage = task?.image
            let size = CGSize(width: 100, height: 100)
            UIGraphicsBeginImageContext(size)
            pinImage!.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
            let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
            
            annotationView?.image = resizedImage
            annotationView?.annotation = annotation
        }
        
        return annotationView
    }
    
}


