import UIKit

class ListTableViewCell: UITableViewCell {
    
    var task: Task? {
        didSet {
            if let task = task {
                titleLabel.text = task.title
            }
        }
    }
    
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
