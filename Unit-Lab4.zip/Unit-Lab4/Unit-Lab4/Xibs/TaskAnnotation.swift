
import UIKit

class TaskAnnotation: UIView {

    @IBOutlet weak var annotationImage: UIImageView!
    
}
